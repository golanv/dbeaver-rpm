package org.jkiss.dbeaver.ui.help;

import org.jkiss.dbeaver.ui.views.BaseBrowserView;

/**
 * Help view
 */
public class LightweightHelpView extends BaseBrowserView {

    public LightweightHelpView()
    {
    }
}
