Some icons left here for backward compatibility.

Editor icons pathes are saved in workbench so we should keep them here for a few more versions.
Search icons can't be located in different plugins - Eclipse limitation.
