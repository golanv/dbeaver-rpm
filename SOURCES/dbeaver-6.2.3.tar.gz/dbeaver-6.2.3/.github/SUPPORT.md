# DBeaver Support

If you're looking for support for DBEaver there are many options, check out:

* User Documentation &mdash; [DBeaver WIKI](https://github.com/dbeaver/dbeaver/wiki)
* [DBeaver Issue tracker](https://github.com/dbeaver/dbeaver/issues)
* <a href="mailto:dbeaver@jkiss.org">Support by email</a>

