# DBeaver Support

If you're looking for support for DBeaver Community then there are two options:

* User Documentation &mdash; [DBeaver WIKI](https://github.com/dbeaver/dbeaver/wiki)
* [DBeaver Issue tracker](https://github.com/dbeaver/dbeaver/issues)


